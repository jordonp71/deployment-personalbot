/*export async function handler(event, context) {
  if (event.httpMethod === "OPTIONS") {
    return { statusCode: 204, headers: cors(), body: "" };
  }
  if (event.httpMethod !== "POST") {
    return { statusCode: 405, headers: cors(), body: "Only POST allowed" };
  }

  try {
    const N8N_WEBHOOK_URL = process.env.N8N_WEBHOOK_URL; // e.g. https://your.app.n8n.cloud/webhook/xxxx/chat
    const BASIC_USER = process.env.BASIC_USER;
    const BASIC_PASS = process.env.BASIC_PASS;

    // 1) (Optional) if API Gateway marked body as base64, decode it first.
    //    Otherwise forward as-is. This prevents accidental mutation.
    const incomingBody = event.isBase64Encoded
      ? Buffer.from(event.body || "", "base64")
      : (event.body ?? "");

    // 2) DEBUG: log what arrived (string or buffer length), and any client-sent hash
    console.log("🟦 Incoming content-type:", event.headers?.["content-type"]);
    console.log("🟦 Incoming body sample:", typeof incomingBody === "string" ? incomingBody.slice(0, 300) : `<Buffer length=${incomingBody.length}>`);
    console.log("🟦 X-Body-Hash header (if provided):", event.headers?.["x-body-hash"]);

    const auth = Buffer.from(`${BASIC_USER}:${BASIC_PASS}`).toString("base64");

    // 3) Forward the body UNCHANGED to n8n
    const upstream = await fetch(N8N_WEBHOOK_URL, {
      method: "POST",
      headers: {
        "Content-Type": event.headers["content-type"] || "application/json",
        "Authorization": `Basic ${auth}`
      },
      body: incomingBody
    });

    // 4) Read + log n8n’s response (handy while testing)
    const text = await upstream.text();
    console.log("🟩 n8n status:", upstream.status);
    console.log("🟩 n8n content-type:", upstream.headers.get("content-type"));
    console.log("🟩 n8n response sample:", text.slice(0, 300));

    return {
      statusCode: upstream.status,
      headers: { ...cors(), "Content-Type": upstream.headers.get("content-type") || "application/json" },
      body: text
    };
  } catch (e) {
    console.error("🟥 Proxy error:", e);
    return {
      statusCode: 502,
      headers: { ...cors(), "Content-Type": "application/json" },
      body: JSON.stringify({ error: "Proxy error", detail: String(e) })
    };
  }
}

function cors() {
  return {
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Methods": "POST, OPTIONS",
    "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Body-Hash",
    "Access-Control-Max-Age": "86400"
  };
}

*/
